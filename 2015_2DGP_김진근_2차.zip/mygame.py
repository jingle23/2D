__author__ = '김진근'

import game_framework

# fill here

import start_state

import main_state

game_framework.run(start_state)