__author__ = '김진근'

import game_framework

import start_state

import main_state

game_framework.run(start_state)